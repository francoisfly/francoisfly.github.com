﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win32Api
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetCompatibleTextRenderingDefault(false);
            //调用 FindWindow 方法，若窗口存在则取得窗口句柄，否则返回NULL
            IntPtr ihand = Program.FindWindow(null, "Form1");  //第二个参数窗体的名称title
            if (ihand != IntPtr.Zero)
            {
                //测试 不同方法 返回的窗口的 句柄 是否一致
                MessageBox.Show("WinAPI  FindWindow 方法 ：   " + ihand.ToString());
                ShowWindowAsync(ihand, SW_SHOWMAXIMIZED);
                SetForegroundWindow(ihand);
                byte[] arr = System.Text.Encoding.Default.GetBytes("我来传递消息");
                int len = arr.Length;
                COPYDATASTRUCT cdata;
                cdata.dwData = (IntPtr)100;
                cdata.lpData = "我来传递消息";
                cdata.cData = len + 1;
                SendMessage(ihand, WM_COPYDATA, 0, ref cdata);//发送消息

            }
            else
            {
                //第一次创建的时候提示
                MessageBox.Show("窗口第一次打开");
                Application.Run(new Form1());
            }

            //方法二
            //Process process = RuningInstance();
            //if (process == null)
            //{
            //    Application.Run(new Form1());
            //}
            //else
            //{            
            //    HandleRunningInstance(process);
            //}
        }

        //取得已经运行的窗口的 进程实例
        private static Process RuningInstance()
        {
            Process currentProcess = Process.GetCurrentProcess();
            Process[] Processes = Process.GetProcessesByName(currentProcess.ProcessName);
            foreach (Process process in Processes)
            {
                if (process.Id != currentProcess.Id)
                {
                    if (System.Reflection.Assembly.GetExecutingAssembly().Location.Replace("/", "//") == currentProcess.MainModule.FileName)
                    {
                        return process;
                    }
                }
            }
            return null;
        }

        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool ShowWindowAsync(IntPtr hWnd, int cmdShow);  //显示窗体

        [System.Runtime.InteropServices.DllImport("User32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);           //函数将创建指定窗口的线程设置到前台，并且激活该窗口

        [System.Runtime.InteropServices.DllImport("User32.dll")]
        public static extern IntPtr FindWindow(string IpClassName, string IpWindowName);//该函数获得一个顶层窗口的句柄，该窗口的类名和窗口名与给定的字符串相匹配。这个函数不查找子窗口。在查找时不区分大小写

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hwnd, int wMsg, int wParam, ref COPYDATASTRUCT lParam); //发送消息


        const int SW_HIDE = 0;   //隐藏窗口并激活其他窗口
        const int SW_SHOWNORMAL = 1; //激活并显示一个窗口。如果窗口被最小化或最大化，系统将其恢复到原来的尺寸和大小。应用程序在第一次显示窗口的时候应该指定此标志
        const int SW_SHOWMINIMIZED = 2;   //激活窗口并将其最小化
        const int SW_SHOWMAXIMIZED = 3;   //激活窗口并将其最大化
        const int SW_SHOWNOACTIVATE = 4;
        const int SW_SHOW = 5;  //在窗口原来的位置以原来的尺寸激活和显示窗口。
        const int SW_MINIMIZE = 6;  //最小化指定的窗口并且激活在Z序中的下一个顶层窗口。
        const int SW_SHOWMINNOACTIVE = 7; //以窗口原来的状态显示窗口。激活窗口仍然维持激活状态。
        const int SW_SHOWNA = 8; //激活并显示窗口。如果窗口最小化或最大化，则系统将窗口恢复到原来的尺寸和位置。在恢复最小化窗口时，应用程序应该指定这个标志。
        const int SW_RESTORE = 9;  //依据在STARTUPINFO结构中指定的SW_FLAG标志设定显示状态，STARTUPINFO结构是由启动应用程序的程序传递给CreateProcess函数的。
        const int SW_SHOWDEFAULT = 10;
        const int SW_FORCEMINIMIZE = 11;

        //当一个应用程序传递数据给另一个应用程序时发送此消息   
        const int WM_COPYDATA = 0x4A;

        public struct COPYDATASTRUCT
        {
            public IntPtr dwData;
            public int cData;
            [MarshalAs(UnmanagedType.LPStr)]
            public string lpData;
        }

    }
}
